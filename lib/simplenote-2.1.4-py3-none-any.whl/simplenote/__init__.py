# -*- coding: utf-8 -*-

from .simplenote import Simplenote, SimplenoteLoginFailed

__author__ = "Daniel Schauenberg"
__version__ = "2.1.4"
__license__ = "MIT"
