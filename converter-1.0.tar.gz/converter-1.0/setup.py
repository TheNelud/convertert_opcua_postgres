from setuptools import setup, find_packages

setup(
    name="converter",
    version="1.0",
    author=",by TheNelud",
    author_email="rpvdev@vk.com",
    description="Converter for opcua in postgres ",
    packages=find_packages(),
)
