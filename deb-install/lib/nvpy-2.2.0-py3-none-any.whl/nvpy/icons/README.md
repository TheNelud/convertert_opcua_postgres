nvpy icon information
=====================

[Minicar icon][1] by [Cemagraphics][2].

Converted to ico file with:

	# you can specify more source png files to be backed into the same ICO
	icotool -c -o nvpy.ico nvpy_icon_64x64.png

[1]: http://www.iconfinder.com/icondetails/67531/64/_icon
[2]: http://cemagraphics.deviantart.com/
