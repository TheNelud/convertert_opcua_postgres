def unicode(x, y):
    return x
